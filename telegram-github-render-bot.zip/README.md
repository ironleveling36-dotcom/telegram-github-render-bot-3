# Telegram → New Public GitHub Repository Bot

Each ZIP sent to the Telegram bot creates a new public GitHub repository under the
configured GitHub account, uploads the ZIP, and replies with the repository/file URL.

## Render

Create a Render Worker from this repository. Build:

    pip install -r requirements.txt

Start:

    python bot.py

Environment variables:

- TELEGRAM_BOT_TOKEN
- GITHUB_TOKEN
- GITHUB_OWNER
- MAX_TELEGRAM_FILE_MB (optional)

## GitHub token

Create a GitHub fine-grained personal access token with repository creation and
repository contents write permission for the target account. Keep the token only
in Render Environment Variables.

## File size

The GitHub Contents API used here limits a single uploaded file to 100 MB.
For larger ZIPs, Git LFS or another storage design is required.
