import os
import re
import tempfile
from pathlib import Path

import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

TELEGRAM_BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
GITHUB_TOKEN = os.environ["GITHUB_TOKEN"]
GITHUB_OWNER = os.environ["GITHUB_OWNER"]
GITHUB_API = "https://api.github.com"

MAX_TELEGRAM_FILE_MB = int(os.getenv("MAX_TELEGRAM_FILE_MB", "2000"))

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
})

def clean_repo_name(filename: str) -> str:
    stem = Path(filename).stem
    name = re.sub(r"[^A-Za-z0-9._-]+", "-", stem).strip("-._")
    return (name or "upload")[:90]

def repo_exists(name: str) -> bool:
    r = session.get(f"{GITHUB_API}/repos/{GITHUB_OWNER}/{name}", timeout=30)
    if r.status_code == 404:
        return False
    r.raise_for_status()
    return True

def unique_repo_name(base: str) -> str:
    if not repo_exists(base):
        return base
    for i in range(2, 10000):
        candidate = f"{base}-{i}"
        if not repo_exists(candidate):
            return candidate
    raise RuntimeError("Could not find a unique repository name.")

def create_repo(name: str):
    # Creates a public repository under the authenticated GitHub account.
    r = session.post(
        f"{GITHUB_API}/user/repos",
        json={
            "name": name,
            "description": f"Telegram upload: {name}.zip",
            "private": False,
            "auto_init": False,
        },
        timeout=30,
    )
    r.raise_for_status()
    return r.json()

def upload_file_to_repo(repo_name: str, local_path: str, remote_name: str):
    size = os.path.getsize(local_path)
    # GitHub Contents API is intentionally not used for large ZIPs.
    # GitHub's REST Contents API has practical limits; use Git LFS for large files.
    if size > 100 * 1024 * 1024:
        raise RuntimeError(
            "ZIP is larger than 100 MB. GitHub repository uploads through this bot "
            "are limited to 100 MB per file. Use a smaller ZIP or Git LFS."
        )

    with open(local_path, "rb") as f:
        content = f.read()

    import base64
    encoded = base64.b64encode(content).decode("ascii")

    r = session.put(
        f"{GITHUB_API}/repos/{GITHUB_OWNER}/{repo_name}/contents/{remote_name}",
        json={
            "message": f"Upload {remote_name}",
            "content": encoded,
        },
        timeout=120,
    )
    r.raise_for_status()
    return r.json()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔥 Send me a ZIP file. I will create a new public GitHub repository, "
        "upload the ZIP, and return the repository link."
    )

async def handle_zip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    document = update.message.document
    if not document:
        return

    filename = document.file_name or "upload.zip"
    if not filename.lower().endswith(".zip"):
        await update.message.reply_text("Please send a .zip file.")
        return

    file_size = document.file_size or 0
    if file_size > MAX_TELEGRAM_FILE_MB * 1024 * 1024:
        await update.message.reply_text(
            f"File is larger than the configured Telegram limit of "
            f"{MAX_TELEGRAM_FILE_MB} MB."
        )
        return

    status = await update.message.reply_text("⏳ Downloading ZIP...")

    try:
        tg_file = await context.bot.get_file(document.file_id)

        with tempfile.TemporaryDirectory() as tmp:
            local_path = os.path.join(tmp, filename)
            await tg_file.download_to_drive(local_path)

            await status.edit_text("📦 Creating a new public GitHub repository...")
            repo_name = unique_repo_name(clean_repo_name(filename))
            repo = create_repo(repo_name)

            await status.edit_text("🚀 Uploading ZIP to GitHub...")
            upload_file_to_repo(repo_name, local_path, filename)

            html_url = repo["html_url"]
            raw_url = (
                f"https://github.com/{GITHUB_OWNER}/{repo_name}/blob/main/"
                f"{requests.utils.quote(filename, safe='')}"
            )

            await status.edit_text(
                "✅ Upload successful!\n\n"
                f"Repository:\n{html_url}\n\n"
                f"File:\n{raw_url}"
            )

    except requests.HTTPError as e:
        detail = ""
        try:
            detail = e.response.json().get("message", "")
        except Exception:
            pass
        await status.edit_text(f"❌ GitHub error: {detail or e}")
    except Exception as e:
        await status.edit_text(f"❌ Upload failed: {e}")

def main():
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_zip))
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
